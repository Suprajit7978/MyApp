package com.example.videoplaerapp.interfaces;

public interface ClickListener {
    void onClickListener(String path);
}
