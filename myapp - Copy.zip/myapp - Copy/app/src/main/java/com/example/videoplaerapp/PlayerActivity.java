package com.example.videoplaerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

public class PlayerActivity extends AppCompatActivity {
    PlayerView playerView;
    SimpleExoPlayer exoPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        playerView=findViewById(R.id.videoplayer);
        setScreenorientation(getIntent().getStringExtra("Filepath"));

    }

    private void showVideo(String filepath) {

        exoPlayer = ExoPlayerFactory.newSimpleInstance(PlayerActivity.this);
        playerView.setPlayer(exoPlayer);
        DataSource.Factory datasource=new DefaultDataSourceFactory
                (PlayerActivity.this, Util.getUserAgent
                        (PlayerActivity.this,getString(R.string.app_name)));
        MediaSource videoSource=new ExtractorMediaSource.
                Factory(datasource).createMediaSource(Uri.parse(filepath));
        exoPlayer.prepare(videoSource);
        exoPlayer.setPlayWhenReady(true);


    }

    private void setScreenorientation(String filePath){
        MediaPlayer mediaPlayer=new MediaPlayer();
        try {
            mediaPlayer.setDataSource(filePath);
            mediaPlayer.prepare();
            mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override
                public void onVideoSizeChanged(MediaPlayer mediaPlayer, int width, int height) {
                    if(width<height){
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT);
                        showVideo(filePath);

                    }else {
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE);
                        showVideo(filePath);
                    }
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        if(exoPlayer!=null){
            exoPlayer.release();
        }
        if(exoPlayer!=null){
            if(exoPlayer.isLoading()){
                exoPlayer.release();
            }
        }
        if(exoPlayer!=null){
            if(exoPlayer.isPlayingAd()){
                exoPlayer.release();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(exoPlayer!=null){
            exoPlayer.release();
        }
        if(exoPlayer!=null){
            if(exoPlayer.isLoading()){
                exoPlayer.release();
            }
        }
        if(exoPlayer!=null){
            if(exoPlayer.isPlayingAd()){
                exoPlayer.release();
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(exoPlayer!=null){
            exoPlayer.release();
        }
        if(exoPlayer!=null){
            if(exoPlayer.isLoading()){
                exoPlayer.release();
            }
        }
        if(exoPlayer!=null){
            if(exoPlayer.isPlayingAd()){
                exoPlayer.release();
            }
        }
    }
}
