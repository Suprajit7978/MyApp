package com.example.videoplaerapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.videoplaerapp.PlayerActivity;
import com.example.videoplaerapp.R;
import com.example.videoplaerapp.interfaces.ClickListener;
import com.example.videoplaerapp.model.VideoModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class VideoAdapter extends RecyclerView.Adapter
{
    List<VideoModel> videoModelArrayList=new ArrayList<>();
    Context context;
    ClickListener clickListener;

    public VideoAdapter(List<VideoModel> videoModelArrayList, Context context, ClickListener clickListener) {
        this.videoModelArrayList = videoModelArrayList;
        this.context = context;
        this.clickListener = clickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView duration;
        private TextView filePath;
        private ImageView thumImage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title=itemView.findViewById(R.id.title);
            duration=itemView.findViewById(R.id.duration);
            filePath=itemView.findViewById(R.id.filePath);
            thumImage=itemView.findViewById(R.id.thumImage);

        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_video_list,viewGroup,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int i) {
        ViewHolder viewHolder=(ViewHolder)holder;

        VideoModel videoModel=videoModelArrayList.get(i);
        viewHolder.title.setText(videoModel.getFileName());
        viewHolder.filePath.setText(videoModel.getFilePath());
        MediaPlayer mediaPlayer=MediaPlayer.create(context, Uri.fromFile(new File(videoModel.getFilePath())));

        double mSec=0;
            if(mediaPlayer!=null){
                mSec=mediaPlayer.getDuration();
            }

            double minute=(mSec%3600)/60;
        viewHolder.duration.setText("" +String.format("%.2f",minute));
        Glide.with(context)
                .load(videoModel.getFilePath())
                .into(viewHolder.thumImage);
        double finalMSec = mSec;
        viewHolder.thumImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(finalMSec ==0){
                    Toast.makeText(context, "Invalid Video", Toast.LENGTH_SHORT).show();
                }else {
                    clickListener.onClickListener(videoModel.getFilePath());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return videoModelArrayList.size();
    }
}
